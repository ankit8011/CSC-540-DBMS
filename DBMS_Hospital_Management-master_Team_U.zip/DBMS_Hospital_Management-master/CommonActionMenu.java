
public class CommonActionMenu {
    public static void commonActions() {
        System.out.println("1. View");
        System.out.println("2. Add");
        System.out.println("3. Edit");
        System.out.println("4. Delete");
    }
}