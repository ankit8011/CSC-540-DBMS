/**
 * This java File holds all the options for the home menu which is all the
 * tables the user can navigate to
 */
public class HomeMenu {
    public static void homeMenuOptions() {

        System.out.println("1. Patients");
        System.out.println("2. Staff");
        System.out.println("3. Check Hospital Space");
        // System.out.println("2. Doctors");
        // System.out.println("3. Nurses");
        // System.out.println("4. Reception Staff");
        System.out.println("4. Check In information");
        // System.out.println("5. Billing Staff");
        System.out.println("5. Billing Account");
        System.out.println("6. Medical Record");
        System.out.println("7. Test");
        System.out.println("8. Treatment");
        System.out.println("9. Wards");
        System.out.println("10. Beds");
        System.out.println("11. Tests For Patients");
        System.out.println("12. Reports");
        System.out.println("13. Exit");

    }
}
